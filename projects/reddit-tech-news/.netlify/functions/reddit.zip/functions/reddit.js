var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var reddit_exports = {};
__export(reddit_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(reddit_exports);
var import_axios = __toESM(require("axios"), 1);
const handler = async (event) => {
  try {
    const redditRss = "https://www.reddit.com/r/SaaS+SideProject+startups/top.rss?t=month&limit=15";
    const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(redditRss)}`;
    const res = await import_axios.default.get(url, { timeout: 8e3 });
    const result = res.data;
    if (result.status !== "ok") {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Gateway RSS falhou" })
      };
    }
    const formattedData = {
      data: {
        children: result.items.map((item) => ({
          data: {
            id: item.guid,
            title: item.title,
            author: item.author,
            permalink: item.link.replace("https://www.reddit.com", ""),
            ups: 100,
            num_comments: 10,
            thumbnail: item.thumbnail || ""
          }
        })),
        after: null
      }
    };
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formattedData)
    };
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: e.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
